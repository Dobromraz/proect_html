import sqlite3

def get_connection():
    connection = sqlite3.connect('prognos.db')
    connection.row_factory = sqlite3.Row
    return connection

def init_db():
    connection = get_connection()
    cursor = connection.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL
)
                ''')
    connection.commit()
    connection.close()

def regist_db(username, email, password_hash):
    connection = get_connection()
    cursor = connection.cursor()
    cursor.execute('INSERT INTO users (username, email, password_hash) VALUES (?,?,?)', (username, email, password_hash))
    connection.commit()
    connection.close()

