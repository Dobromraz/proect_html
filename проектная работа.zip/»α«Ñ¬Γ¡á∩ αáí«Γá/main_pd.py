import pandas as pd

df = pd.read_csv('prognosic_scv/credit.csv')

df = df.iloc[::2]

print(df.info)