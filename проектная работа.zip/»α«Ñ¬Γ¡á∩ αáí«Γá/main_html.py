from flask import Flask, render_template, request, redirect, url_for
import database

app = Flask(__name__)

@app.route('/')
def main_page():
    return render_template('index.html')


database.init_db()
app.run()